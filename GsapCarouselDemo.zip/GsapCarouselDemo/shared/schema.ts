import { pgTable, text, serial, integer, boolean, timestamp } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
});

export const collections = pgTable("collections", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  description: text("description"),
  isActive: boolean("is_active").default(false),
  createdAt: timestamp("created_at").defaultNow(),
});

export const logos = pgTable("logos", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  description: text("description"),
  imageUrl: text("image_url").notNull(),
  category: text("category"),
  tags: text("tags").array().default([]),
  userId: integer("user_id").references(() => users.id),
  collectionId: integer("collection_id").references(() => collections.id),
  createdAt: timestamp("created_at").defaultNow(),
});

export const feedback = pgTable("feedback", {
  id: serial("id").primaryKey(),
  isPositive: boolean("is_positive").notNull(),
  comment: text("comment"),
  logoId: integer("logo_id").references(() => logos.id),
  submittedAt: timestamp("submitted_at").defaultNow(),
});

export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  password: true,
});

export const insertCollectionSchema = createInsertSchema(collections).pick({
  name: true,
  description: true,
  isActive: true,
});

export const insertLogoSchema = createInsertSchema(logos).pick({
  name: true,
  description: true,
  imageUrl: true,
  category: true,
  tags: true,
  userId: true,
  collectionId: true,
}).extend({
  description: z.string().optional(),
  category: z.string().optional(),
  tags: z.array(z.string()).optional(),
  userId: z.number().optional().nullable(),
  collectionId: z.number().optional().nullable(),
});

export const insertFeedbackSchema = createInsertSchema(feedback).pick({
  isPositive: true,
  comment: true,
  logoId: true,
});

export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;

export type InsertCollection = z.infer<typeof insertCollectionSchema>;
export type Collection = typeof collections.$inferSelect;

export type InsertLogo = z.infer<typeof insertLogoSchema>;
export type Logo = typeof logos.$inferSelect;

export type InsertFeedback = z.infer<typeof insertFeedbackSchema>;
export type Feedback = typeof feedback.$inferSelect;

import { useState, useCallback, useRef, useEffect } from "react";

export function useCarousel(totalItems: number) {
  const [currentIndex, setCurrentIndex] = useState(0);
  const [isAutoPlaying, setIsAutoPlaying] = useState(false);
  const [currentScale, setCurrentScale] = useState(0.3);
  const autoPlayIntervalRef = useRef<NodeJS.Timeout | null>(null);

  const rotateTo = useCallback((index: number) => {
    if (index >= 0 && index < totalItems) {
      setCurrentIndex(index);
    }
  }, [totalItems]);

  const goToNext = useCallback(() => {
    setCurrentIndex((prev) => (prev + 1) % totalItems);
  }, [totalItems]);

  const goToPrev = useCallback(() => {
    setCurrentIndex((prev) => (prev - 1 + totalItems) % totalItems);
  }, [totalItems]);

  const startAutoPlay = useCallback(() => {
    if (autoPlayIntervalRef.current) {
      clearInterval(autoPlayIntervalRef.current);
    }
    
    autoPlayIntervalRef.current = setInterval(() => {
      setCurrentIndex((prev) => (prev + 1) % totalItems);
    }, 3000);
    
    setIsAutoPlaying(true);
  }, [totalItems]);

  const stopAutoPlay = useCallback(() => {
    if (autoPlayIntervalRef.current) {
      clearInterval(autoPlayIntervalRef.current);
      autoPlayIntervalRef.current = null;
    }
    setIsAutoPlaying(false);
  }, []);

  const zoomIn = useCallback(() => {
    setCurrentScale((prev) => Math.min(prev + 0.2, 2));
  }, []);

  const zoomOut = useCallback(() => {
    setCurrentScale((prev) => Math.max(prev - 0.2, 0.5));
  }, []);

  // Keyboard navigation
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      switch (e.key) {
        case 'ArrowLeft':
          goToPrev();
          break;
        case 'ArrowRight':
          goToNext();
          break;
        case ' ':
          e.preventDefault();
          if (isAutoPlaying) {
            stopAutoPlay();
          } else {
            startAutoPlay();
          }
          break;
      }
    };

    document.addEventListener('keydown', handleKeyDown);
    return () => document.removeEventListener('keydown', handleKeyDown);
  }, [goToPrev, goToNext, isAutoPlaying, startAutoPlay, stopAutoPlay]);

  // Cleanup interval on unmount
  useEffect(() => {
    return () => {
      if (autoPlayIntervalRef.current) {
        clearInterval(autoPlayIntervalRef.current);
      }
    };
  }, []);

  return {
    currentIndex,
    isAutoPlaying,
    currentScale,
    rotateTo,
    goToNext,
    goToPrev,
    startAutoPlay,
    stopAutoPlay,
    zoomIn,
    zoomOut,
  };
}

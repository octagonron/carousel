import { gsap as gsapCore } from "gsap";

// Re-export gsap with any custom configuration
export const gsap = gsapCore;

// Custom GSAP utilities for the carousel
export const carouselUtils = {
  toRad: (deg: number) => (deg * Math.PI) / 180,
  toDeg: (rad: number) => (rad * 180) / Math.PI,
  
  // Create a 3D rotation timeline
  create3DRotation: (element: Element, angle: number, duration: number = 1) => {
    return gsap.to(element, {
      rotationY: angle,
      duration,
      ease: "power2.inOut",
    });
  },

  // Create a zoom animation
  createZoom: (element: Element, scale: number, duration: number = 0.3) => {
    return gsap.to(element, {
      scale,
      duration,
      ease: "power2.out",
    });
  },

  // Create entrance animation for carousel items
  createEntranceAnimation: (elements: NodeListOf<Element> | Element[]) => {
    return gsap.from(elements, {
      scale: 0,
      opacity: 0,
      duration: 1,
      stagger: 0.1,
      ease: "back.out(1.7)",
      delay: 0.5,
    });
  },

  // Create smooth opacity transition
  createFadeTransition: (element: Element, opacity: number, duration: number = 0.5) => {
    return gsap.to(element, {
      opacity,
      duration,
      ease: "power2.out",
    });
  },
};

export default gsap;

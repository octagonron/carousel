import { useEffect, useRef, useState } from "react";
import { Play, Pause, ChevronLeft, ChevronRight, ZoomIn, ZoomOut, MessageSquare, Sun, Moon } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { useCarousel } from "@/hooks/use-carousel";
import { gsap } from "@/lib/gsap";
import type { Logo, Feedback } from "@shared/schema";
import { useQuery } from "@tanstack/react-query";
import { FeedbackModal } from "./feedback-modal";

interface Carousel3DProps {
  logos: Logo[];
}

export function Carousel3D({ logos }: Carousel3DProps) {
  const containerRef = useRef<HTMLDivElement>(null);
  const [isFeedbackModalOpen, setIsFeedbackModalOpen] = useState(false);
  const [selectedLogoId, setSelectedLogoId] = useState<number | undefined>(undefined);
  const [isDarkMode, setIsDarkMode] = useState(true);
  
  const {
    currentIndex,
    isAutoPlaying,
    currentScale,
    rotateTo,
    startAutoPlay,
    stopAutoPlay,
    zoomIn,
    zoomOut,
    goToNext,
    goToPrev
  } = useCarousel(logos.length);

  // Fetch all feedback to determine logo ratings
  const { data: allFeedback = [] } = useQuery<Feedback[]>({
    queryKey: ["/api/feedback"],
  });

  // Calculate thumbs up/down ratio for each logo
  const getLogoFeedback = (logoId: number) => {
    const logoFeedback = allFeedback.filter(f => f.logoId === logoId);
    if (logoFeedback.length === 0) return null;
    
    const positiveCount = logoFeedback.filter(f => f.isPositive).length;
    const totalCount = logoFeedback.length;
    const positiveRatio = positiveCount / totalCount;
    
    return {
      positiveCount,
      totalCount,
      isPositive: positiveRatio >= 0.5, // 50%+ thumbs up = positive
    };
  };

  // Get neon color based on logo index and feedback - dynamic color cycling
  const getNeonClass = (logo: Logo, index: number) => {
    const feedback = getLogoFeedback(logo.id);
    
    if (feedback) {
      return feedback.isPositive ? 'feedback-positive' : 'feedback-negative';
    }
    
    // Expanded neon colors for larger collections
    const neonColors = [
      'neon-blue', 'neon-purple', 'neon-pink', 'neon-cyan', 'neon-green', 'neon-amber',
      'neon-blue', 'neon-purple', 'neon-pink', 'neon-cyan', 'neon-green', 'neon-red'
    ];
    return neonColors[index % neonColors.length];
  };

  // Get dynamic background variation for each logo
  const getBackgroundStyle = (index: number) => {
    const variations = [
      { filter: 'hue-rotate(0deg) saturate(1.2)', overlay: 'from-blue-900/50' },
      { filter: 'hue-rotate(60deg) saturate(1.1)', overlay: 'from-purple-900/50' },
      { filter: 'hue-rotate(120deg) saturate(1.3)', overlay: 'from-green-900/50' },
      { filter: 'hue-rotate(180deg) saturate(1.0)', overlay: 'from-cyan-900/50' },
      { filter: 'hue-rotate(240deg) saturate(1.2)', overlay: 'from-pink-900/50' },
      { filter: 'hue-rotate(300deg) saturate(1.1)', overlay: 'from-red-900/50' },
    ];
    return variations[index % variations.length];
  };

  useEffect(() => {
    if (!containerRef.current || logos.length === 0) return;

    const items = containerRef.current.querySelectorAll('.carousel-item');
    
    // Initialize carousel positions - dynamic radius based on number of items
    const baseRadius = 300;
    const radiusIncrement = Math.max(0, (logos.length - 5) * 20); // Increase radius for more items
    const radius = baseRadius + radiusIncrement;
    
    items.forEach((item, index) => {
      const angle = (index * 360) / logos.length;
      const angleInRad = (angle * Math.PI) / 180;
      const x = Math.sin(angleInRad) * radius;
      const z = Math.cos(angleInRad) * radius;
      
      gsap.set(item, {
        rotationY: angle,
        x: x,
        z: z,
        opacity: index === 0 ? 1 : 0.7
      });
    });

    // Add entrance animation
    gsap.from('.carousel-item', {
      scale: 0,
      opacity: 0,
      duration: 1,
      stagger: 0.1,
      ease: "back.out(1.7)",
      delay: 0.5
    });
  }, [logos.length]);

  useEffect(() => {
    if (!containerRef.current) return;

    const rotationAngle = -(currentIndex * 360) / logos.length;
    
    gsap.to(containerRef.current, {
      rotationY: rotationAngle,
      duration: 1,
      ease: "power2.inOut"
    });

    // Update opacity and scale for current item
    const items = containerRef.current.querySelectorAll('.carousel-item');
    items.forEach((item, index) => {
      gsap.to(item, {
        opacity: index === currentIndex ? 1 : 0.7,
        scale: index === currentIndex ? currentScale : currentScale * 0.9,
        duration: 0.5,
        ease: "power2.out"
      });
    });
  }, [currentIndex, currentScale, logos.length]);

  const touchStart = useRef({ x: 0, y: 0, time: 0 });
  const isDragging = useRef(false);

  const handleTouchStart = (e: React.TouchEvent) => {
    touchStart.current = {
      x: e.touches[0].clientX,
      y: e.touches[0].clientY,
      time: Date.now()
    };
    isDragging.current = false;
  };

  const handleTouchMove = (e: React.TouchEvent) => {
    if (!touchStart.current) return;
    
    const deltaX = e.touches[0].clientX - touchStart.current.x;
    const deltaY = e.touches[0].clientY - touchStart.current.y;
    
    // If horizontal movement is greater, we're swiping horizontally
    if (Math.abs(deltaX) > Math.abs(deltaY) && Math.abs(deltaX) > 10) {
      isDragging.current = true;
      e.preventDefault(); // Prevent scrolling when swiping horizontally
    }
  };

  const handleTouchEnd = (e: React.TouchEvent) => {
    if (!touchStart.current || !isDragging.current) return;
    
    const deltaX = e.changedTouches[0].clientX - touchStart.current.x;
    const deltaY = e.changedTouches[0].clientY - touchStart.current.y;
    const deltaTime = Date.now() - touchStart.current.time;
    
    // Check for swipe gesture: horizontal movement > vertical, minimum distance, reasonable speed
    if (Math.abs(deltaX) > Math.abs(deltaY) && Math.abs(deltaX) > 50 && deltaTime < 500) {
      if (deltaX > 0) {
        goToPrev(); // Swipe right = previous
      } else {
        goToNext(); // Swipe left = next
      }
    }
    
    isDragging.current = false;
  };

  const getTagColor = (tag: string) => {
    const colors = {
      'Design': 'bg-blue-600/20 text-blue-300',
      'Creative': 'bg-amber-600/20 text-amber-300',
      'Branding': 'bg-red-600/20 text-red-300',
      'Professional': 'bg-purple-600/20 text-purple-300',
      'Contemporary': 'bg-green-600/20 text-green-300',
      'Balanced': 'bg-blue-600/20 text-blue-300',
      'Artistic': 'bg-pink-600/20 text-pink-300',
      'Versatile': 'bg-purple-600/20 text-purple-300',
      'Sophisticated': 'bg-orange-600/20 text-orange-300',
      'Memorable': 'bg-gray-600/20 text-gray-300',
      'Dynamic': 'bg-cyan-600/20 text-cyan-300',
      'Conceptual': 'bg-indigo-600/20 text-indigo-300',
      'Elegant': 'bg-violet-600/20 text-violet-300',
      'Timeless': 'bg-emerald-600/20 text-emerald-300',
      'Bold': 'bg-red-600/20 text-red-300',
      'Optimized': 'bg-yellow-600/20 text-yellow-300',
      'Corporate': 'bg-slate-600/20 text-slate-300',
      'Strategic': 'bg-teal-600/20 text-teal-300',
      'Innovative': 'bg-lime-600/20 text-lime-300',
      'Comprehensive': 'bg-rose-600/20 text-rose-300'
    };
    return colors[tag as keyof typeof colors] || 'bg-slate-600/20 text-slate-300';
  };

  if (logos.length === 0) {
    return (
      <section className="py-20">
        <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <p className="text-slate-400 text-lg">No logos available</p>
        </div>
      </section>
    );
  }

  return (
    <section className="py-20">
      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Carousel Controls */}
        <div className="flex items-center justify-center space-x-6 mb-12">
          <Button
            onClick={goToPrev}
            variant="outline"
            size="icon"
            className="w-12 h-12 neon-glassmorphism neon-blue hover:scale-110 transition-all duration-300"
          >
            <ChevronLeft className="h-4 w-4" />
          </Button>
          
          <Button
            onClick={isAutoPlaying ? stopAutoPlay : startAutoPlay}
            size="icon"
            className="w-14 h-14 neon-glassmorphism neon-purple hover:scale-110 transition-all duration-300"
          >
            {isAutoPlaying ? <Pause className="h-4 w-4" /> : <Play className="h-4 w-4" />}
          </Button>

          {/* Theme Toggle */}
          <Button
            onClick={() => setIsDarkMode(!isDarkMode)}
            size="icon"
            className="w-12 h-12 neon-glassmorphism neon-amber hover:scale-110 transition-all duration-300"
          >
            {isDarkMode ? <Sun className="h-4 w-4" /> : <Moon className="h-4 w-4" />}
          </Button>
          
          <Button
            onClick={goToNext}
            variant="outline"
            size="icon"
            className="w-12 h-12 neon-glassmorphism neon-blue hover:scale-110 transition-all duration-300"
          >
            <ChevronRight className="h-4 w-4" />
          </Button>
        </div>

        {/* 3D Carousel Container - Dynamic height based on number of items */}
        <div className={`relative perspective-1000 ${logos.length > 15 ? 'h-[600px] md:h-[700px]' : logos.length > 10 ? 'h-[500px] md:h-[600px]' : 'h-96 md:h-[500px]'}`}>
          {/* Background image layer */}
          <div 
            className="absolute inset-0 opacity-10 bg-cover bg-center bg-no-repeat rounded-2xl"
            style={{
              backgroundImage: `url('/logos/backgrond.svg.svg')`,
              filter: 'blur(3px)',
            }}
          />
          
          <div
            ref={containerRef}
            className="absolute inset-0 preserve-3d"
            onTouchStart={handleTouchStart}
            onTouchMove={handleTouchMove}
            onTouchEnd={handleTouchEnd}
          >
            {logos.map((logo, index) => (
              <div
                key={logo.id}
                className="carousel-item absolute inset-0 flex items-center justify-center preserve-3d backface-hidden"
                data-index={index}
              >
                <div className={`w-80 h-96 md:w-96 md:h-[32rem] rounded-2xl shadow-2xl p-6 flex flex-col items-center justify-center transition-all duration-500 cursor-pointer ${
                  isDarkMode 
                    ? (index === currentIndex ? 'neon-glassmorphism-translucent' : 'neon-glassmorphism')
                    : (index === currentIndex ? 'light-glassmorphism-translucent' : 'light-glassmorphism')
                } ${isDarkMode ? getNeonClass(logo, index) : ''}`}>
                  {/* Logo takes up most of the space */}
                  <div className="w-48 h-48 md:w-56 md:h-56 mb-4 flex items-center justify-center">
                    <img
                      src={logo.imageUrl}
                      alt={`${logo.name} logo`}
                      className="w-full h-full object-contain"
                    />
                  </div>
                  
                  {/* Elegant text section */}
                  <div className="text-center space-y-3">
                    <h3 className={`text-xl font-bold drop-shadow-lg tracking-wide ${isDarkMode ? 'text-white' : 'text-slate-800'}`}>{logo.name}</h3>
                    

                    
                    {/* Compact feedback button */}
                    <Button
                      onClick={(e) => {
                        e.stopPropagation();
                        setSelectedLogoId(logo.id);
                        setIsFeedbackModalOpen(true);
                      }}
                      className={`mt-2 px-2 py-1 text-xs backdrop-blur-sm transition-all duration-300 hover:scale-105 ${
                        isDarkMode 
                          ? 'bg-white/10 hover:bg-white/20 text-white/70 hover:text-white border border-white/20 hover:border-white/30'
                          : 'bg-slate-900/10 hover:bg-slate-900/20 text-slate-600 hover:text-slate-800 border border-slate-400/20 hover:border-slate-400/30'
                      }`}
                      size="sm"
                    >
                      <MessageSquare className="w-3 h-3 mr-1" />
                      Feedback
                    </Button>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Navigation Dots - Dynamic layout for many items */}
        <div className={`flex justify-center mt-12 ${logos.length > 20 ? 'flex-wrap max-w-md mx-auto gap-y-2' : 'space-x-3'}`}>
          {logos.map((_, index) => (
            <button
              key={index}
              onClick={() => rotateTo(index)}
              className={`${logos.length > 20 ? 'w-2 h-2 mx-1' : 'w-3 h-3'} rounded-full transition-all ${
                index === currentIndex ? 'bg-blue-500' : 'bg-slate-600 hover:bg-slate-500'
              }`}
              aria-label={`Go to slide ${index + 1}`}
            />
          ))}
        </div>

        {/* Zoom Controls */}
        <div className="flex justify-center mt-8 space-x-4">
          <Button
            onClick={zoomOut}
            variant="outline"
            className="neon-glassmorphism neon-cyan hover:scale-105 transition-all duration-300"
          >
            <ZoomOut className="h-4 w-4 mr-2" />
            Zoom Out
          </Button>
          <Button
            onClick={zoomIn}
            variant="outline"
            className="neon-glassmorphism neon-cyan hover:scale-105 transition-all duration-300"
          >
            <ZoomIn className="h-4 w-4 mr-2" />
            Zoom In
          </Button>
        </div>
      </div>

      {/* Feedback Modal */}
      <FeedbackModal
        isOpen={isFeedbackModalOpen}
        onClose={() => setIsFeedbackModalOpen(false)}
        logoId={selectedLogoId}
      />
    </section>
  );
}

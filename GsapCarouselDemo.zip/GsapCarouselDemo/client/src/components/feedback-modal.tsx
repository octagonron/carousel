import { useState } from "react";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { X, ThumbsUp, ThumbsDown } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { gsap } from "@/lib/gsap";
import { useEffect, useRef } from "react";

interface FeedbackModalProps {
  isOpen: boolean;
  onClose: () => void;
  logoId?: number;
}

export function FeedbackModal({ isOpen, onClose, logoId }: FeedbackModalProps) {
  const [isPositive, setIsPositive] = useState<boolean | null>(null);
  const [comment, setComment] = useState("");
  const modalRef = useRef<HTMLDivElement>(null);
  const contentRef = useRef<HTMLDivElement>(null);
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const feedbackMutation = useMutation({
    mutationFn: async (data: { isPositive: boolean; comment?: string; logoId?: number }) => {
      const response = await apiRequest("POST", "/api/feedback", data);
      return response.json();
    },
    onSuccess: () => {
      toast({
        title: "Thank you for your feedback!",
        description: "Your feedback has been submitted successfully.",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/feedback"] });
      resetForm();
      onClose();
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to submit feedback. Please try again.",
        variant: "destructive",
      });
    },
  });

  const resetForm = () => {
    setIsPositive(null);
    setComment("");
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (isPositive === null) {
      toast({
        title: "Please select thumbs up or down",
        description: "Your feedback is required to submit.",
        variant: "destructive",
      });
      return;
    }

    feedbackMutation.mutate({
      isPositive,
      comment: comment.trim() || undefined,
      logoId,
    });
  };

  const handleBackdropClick = (e: React.MouseEvent) => {
    if (e.target === modalRef.current) {
      onClose();
    }
  };

  // Modal animations
  useEffect(() => {
    if (!contentRef.current) return;

    if (isOpen) {
      gsap.fromTo(contentRef.current, 
        { scale: 0.95, opacity: 0 },
        { scale: 1, opacity: 1, duration: 0.3, ease: "back.out(1.7)" }
      );
    }
  }, [isOpen]);

  const handleClose = () => {
    if (!contentRef.current) {
      onClose();
      return;
    }

    gsap.to(contentRef.current, {
      scale: 0.95,
      opacity: 0,
      duration: 0.2,
      ease: "power2.in",
      onComplete: () => {
        resetForm();
        onClose();
      }
    });
  };

  if (!isOpen) return null;

  return (
    <div
      ref={modalRef}
      className="fixed inset-0 z-50 flex items-center justify-center p-4"
      onClick={handleBackdropClick}
    >
      <div className="absolute inset-0 bg-black/50 backdrop-blur-sm" />
      <div
        ref={contentRef}
        className="relative bg-slate-800 rounded-2xl p-8 max-w-md w-full border border-slate-600"
      >
        <div className="flex items-center justify-between mb-6">
          <h3 className="text-2xl font-semibold">Share Your Feedback</h3>
          <Button
            onClick={handleClose}
            variant="ghost"
            size="icon"
            className="text-slate-400 hover:text-white"
          >
            <X className="h-5 w-5" />
          </Button>
        </div>
        
        <form onSubmit={handleSubmit}>
          <div className="mb-6">
            <label className="block text-sm font-medium mb-3">
              Rate this design
            </label>
            <div className="flex justify-center space-x-6">
              <button
                type="button"
                onClick={() => setIsPositive(true)}
                className={`p-4 rounded-full transition-all duration-200 ${
                  isPositive === true
                    ? 'bg-green-500 text-white scale-110'
                    : 'bg-slate-700 text-slate-400 hover:bg-slate-600 hover:text-green-400'
                }`}
              >
                <ThumbsUp size={32} />
              </button>
              <button
                type="button"
                onClick={() => setIsPositive(false)}
                className={`p-4 rounded-full transition-all duration-200 ${
                  isPositive === false
                    ? 'bg-red-500 text-white scale-110'
                    : 'bg-slate-700 text-slate-400 hover:bg-slate-600 hover:text-red-400'
                }`}
              >
                <ThumbsDown size={32} />
              </button>
            </div>
            <div className="text-center mt-2">
              {isPositive === true && <span className="text-green-400 text-sm">👍 Great design!</span>}
              {isPositive === false && <span className="text-red-400 text-sm">👎 Needs improvement</span>}
            </div>
          </div>
          
          <div className="mb-6">
            <label htmlFor="comment" className="block text-sm font-medium mb-2">
              Your feedback (optional)
            </label>
            <Textarea
              id="comment"
              value={comment}
              onChange={(e) => setComment(e.target.value)}
              rows={4}
              className="w-full bg-slate-700 border border-slate-600 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
              placeholder="Share your thoughts about this design..."
            />
          </div>
          
          <div className="flex space-x-3">
            <Button
              type="button"
              onClick={handleClose}
              variant="outline"
              className="flex-1 border-slate-600 hover:bg-slate-700"
            >
              Cancel
            </Button>
            <Button
              type="submit"
              disabled={feedbackMutation.isPending}
              className="flex-1 bg-blue-600 hover:bg-blue-700"
            >
              {feedbackMutation.isPending ? "Submitting..." : "Submit"}
            </Button>
          </div>
        </form>
      </div>
    </div>
  );
}

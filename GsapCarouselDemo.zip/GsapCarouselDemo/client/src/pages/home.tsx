import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Link } from "wouter";
import type { Logo, Collection } from "@shared/schema";
import { Carousel3D } from "@/components/carousel-3d";
import { FeedbackModal } from "@/components/feedback-modal";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Box, Menu, Settings, Layers } from "lucide-react";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";

export default function Home() {
  const [isFeedbackOpen, setIsFeedbackOpen] = useState(false);

  const { data: logos = [], isLoading } = useQuery<Logo[]>({
    queryKey: ["/api/logos"],
  });

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-slate-900">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-500"></div>
      </div>
    );
  }

  return (
    <div className="bg-slate-900 text-slate-50 font-inter min-h-screen overflow-x-hidden">
      {/* Header */}
      <header className="relative z-50 bg-slate-800/50 backdrop-blur-lg border-b border-slate-700">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            <div className="flex items-center space-x-3">
              <div className="w-10 h-10 bg-gradient-to-br from-blue-500 to-amber-500 rounded-lg flex items-center justify-center">
                <Box className="text-white text-lg" />
              </div>
              <h1 className="text-xl font-semibold">3D Carousel</h1>
            </div>
            
            <nav className="hidden md:flex items-center space-x-8">
              <a href="#" className="text-slate-300 hover:text-white transition-colors">Gallery</a>
              <a href="#" className="text-slate-300 hover:text-white transition-colors">About</a>
              <Button
                onClick={() => setIsFeedbackOpen(true)}
                className="bg-blue-600 hover:bg-blue-700"
              >
                Feedback
              </Button>
            </nav>
            
            <button className="md:hidden text-slate-300 hover:text-white">
              <Menu className="text-xl" />
            </button>
          </div>
        </div>
      </header>
      {/* Main Content */}
      <main className="relative">
        {/* Hero Section */}
        <section className="relative py-20 overflow-hidden">
          <div className="absolute inset-0 bg-gradient-to-br from-slate-900 via-slate-800 to-slate-900"></div>
          <div className="absolute inset-0 opacity-20">
            <div className="absolute top-20 left-10 w-32 h-32 bg-blue-500/20 rounded-full blur-xl animate-float"></div>
            <div className="absolute bottom-20 right-10 w-40 h-40 bg-amber-500/20 rounded-full blur-xl animate-float" style={{animationDelay: '-2s'}}></div>
          </div>
          
          <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
            <h2 className="text-4xl md:text-6xl font-bold mb-6 bg-gradient-to-r from-blue-400 to-amber-400 bg-clip-text text-transparent">Swipe to see Logos</h2>
            <p className="text-slate-300 mb-12 max-w-2xl mx-auto text-[25px]">Zoom Out/In, Toggle Light/Dark, Enjoy!</p>
          </div>
        </section>

        {/* 3D Carousel Section */}
        <Carousel3D logos={logos} />


      </main>
      {/* Feedback Modal */}
      <FeedbackModal
        isOpen={isFeedbackOpen}
        onClose={() => setIsFeedbackOpen(false)}
      />
    </div>
  );
}

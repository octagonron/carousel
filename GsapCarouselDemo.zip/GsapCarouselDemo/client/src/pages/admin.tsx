import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Plus, Upload, Trash2, Edit3, Users } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import type { Logo, User, InsertLogo, Collection, InsertCollection } from "@shared/schema";

export default function Admin() {
  const [selectedUser, setSelectedUser] = useState<number | null>(null);
  const [isAddingLogo, setIsAddingLogo] = useState(false);
  const [editingLogo, setEditingLogo] = useState<Logo | null>(null);
  const [isAddingCollection, setIsAddingCollection] = useState(false);
  const { toast } = useToast();
  const queryClient = useQueryClient();

  // Fetch data
  const { data: users = [] } = useQuery<User[]>({
    queryKey: ["/api/users"],
  });

  const { data: collections = [] } = useQuery<Collection[]>({
    queryKey: ["/api/collections"],
  });

  const { data: allLogos = [] } = useQuery<Logo[]>({
    queryKey: ["/api/admin/logos"],
  });

  // Filter logos by selected user
  const userLogos = selectedUser 
    ? allLogos.filter(logo => logo.userId === selectedUser)
    : allLogos;

  const selectedUserData = users.find(user => user.id === selectedUser);

  // Mutations
  const addLogoMutation = useMutation({
    mutationFn: async (data: InsertLogo) => {
      const response = await apiRequest("POST", "/api/admin/logos", data);
      return response.json();
    },
    onSuccess: () => {
      toast({ title: "Logo added successfully!" });
      queryClient.invalidateQueries({ queryKey: ["/api/admin/logos"] });
      queryClient.invalidateQueries({ queryKey: ["/api/logos"] });
      setIsAddingLogo(false);
    },
    onError: () => {
      toast({ title: "Failed to add logo", variant: "destructive" });
    },
  });

  const updateLogoMutation = useMutation({
    mutationFn: async ({ id, data }: { id: number; data: Partial<InsertLogo> }) => {
      const response = await apiRequest("PATCH", `/api/admin/logos/${id}`, data);
      return response.json();
    },
    onSuccess: () => {
      toast({ title: "Logo updated successfully!" });
      queryClient.invalidateQueries({ queryKey: ["/api/admin/logos"] });
      queryClient.invalidateQueries({ queryKey: ["/api/logos"] });
      setEditingLogo(null);
    },
    onError: () => {
      toast({ title: "Failed to update logo", variant: "destructive" });
    },
  });

  const deleteLogoMutation = useMutation({
    mutationFn: async (id: number) => {
      const response = await apiRequest("DELETE", `/api/admin/logos/${id}`);
      return response.json();
    },
    onSuccess: () => {
      toast({ title: "Logo deleted successfully!" });
      queryClient.invalidateQueries({ queryKey: ["/api/admin/logos"] });
      queryClient.invalidateQueries({ queryKey: ["/api/logos"] });
    },
    onError: () => {
      toast({ title: "Failed to delete logo", variant: "destructive" });
    },
  });

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 to-slate-800 text-white">
      <div className="container mx-auto px-4 py-8">
        <div className="mb-8">
          <h1 className="text-4xl font-bold mb-2">Logo Portfolio Admin</h1>
          <p className="text-slate-300">Manage logo assets for different users and clients</p>
        </div>

        <Card className="bg-slate-800 border-slate-600 mb-6">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Users className="w-5 h-5" />
              Filter by User
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex gap-4 items-end">
              <div className="flex-1">
                <Select value={selectedUser?.toString() || "all"} onValueChange={(value) => setSelectedUser(value === "all" ? null : parseInt(value))}>
                  <SelectTrigger className="bg-slate-700 border-slate-600">
                    <SelectValue placeholder="Select user..." />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All Users</SelectItem>
                    {users.map((user) => (
                      <SelectItem key={user.id} value={user.id.toString()}>
                        {user.username}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <Dialog open={isAddingLogo} onOpenChange={setIsAddingLogo}>
                <DialogTrigger asChild>
                  <Button className="bg-blue-600 hover:bg-blue-700">
                    <Plus className="w-4 h-4 mr-2" />
                    Add Logo
                  </Button>
                </DialogTrigger>
                <DialogContent className="bg-slate-800 border-slate-600 max-w-lg">
                  <DialogHeader>
                    <DialogTitle>Add New Logo</DialogTitle>
                  </DialogHeader>
                  <LogoForm
                    users={users}
                    onSubmit={(data) => addLogoMutation.mutate(data)}
                    isLoading={addLogoMutation.isPending}
                  />
                </DialogContent>
              </Dialog>
            </div>
            {selectedUserData && (
              <div className="mt-4 p-4 bg-slate-700 rounded-lg">
                <p className="text-sm text-slate-300">
                  Showing {userLogos.length} logo(s) for <span className="font-semibold text-white">{selectedUserData.username}</span>
                </p>
              </div>
            )}
          </CardContent>
        </Card>

        {/* Logo Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {userLogos.map((logo) => (
            <Card key={logo.id} className="bg-slate-800 border-slate-600 hover:border-slate-500 transition-colors">
              <CardContent className="p-4">
                <div className="aspect-square bg-slate-700 rounded-lg mb-4 overflow-hidden">
                  <img
                    src={logo.imageUrl}
                    alt={logo.name}
                    className="w-full h-full object-cover"
                  />
                </div>
                <h3 className="font-semibold mb-2">{logo.name}</h3>
                <p className="text-sm text-slate-300 mb-3 line-clamp-2">{logo.description || "No description"}</p>
                
                <div className="flex flex-wrap gap-1 mb-3">
                  {logo.category && (
                    <Badge variant="secondary" className="text-xs">
                      {logo.category}
                    </Badge>
                  )}
                  {logo.tags?.slice(0, 2).map((tag) => (
                    <Badge key={tag} variant="outline" className="text-xs">
                      {tag}
                    </Badge>
                  ))}
                </div>

                <div className="flex gap-2">
                  <Dialog>
                    <DialogTrigger asChild>
                      <Button
                        variant="outline"
                        size="sm"
                        className="flex-1"
                        onClick={() => setEditingLogo(logo)}
                      >
                        <Edit3 className="w-3 h-3 mr-1" />
                        Edit
                      </Button>
                    </DialogTrigger>
                    <DialogContent className="bg-slate-800 border-slate-600 max-w-lg">
                      <DialogHeader>
                        <DialogTitle>Edit Logo</DialogTitle>
                      </DialogHeader>
                      {editingLogo && (
                        <LogoForm
                          users={users}
                          logo={editingLogo}
                          onSubmit={(data) => updateLogoMutation.mutate({ id: editingLogo.id, data })}
                          isLoading={updateLogoMutation.isPending}
                        />
                      )}
                    </DialogContent>
                  </Dialog>
                  <Button
                    variant="destructive"
                    size="sm"
                    onClick={() => deleteLogoMutation.mutate(logo.id)}
                    disabled={deleteLogoMutation.isPending}
                  >
                    <Trash2 className="w-3 h-3" />
                  </Button>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        {userLogos.length === 0 && (
          <Card className="bg-slate-800 border-slate-600">
            <CardContent className="text-center py-12">
              <Upload className="w-12 h-12 mx-auto mb-4 text-slate-400" />
              <h3 className="text-lg font-semibold mb-2">No logos found</h3>
              <p className="text-slate-400 mb-4">
                {selectedUser ? "This user has no logos yet." : "Start by adding your first logo."}
              </p>
              <Button onClick={() => setIsAddingLogo(true)} className="bg-blue-600 hover:bg-blue-700">
                <Plus className="w-4 h-4 mr-2" />
                Add First Logo
              </Button>
            </CardContent>
          </Card>
        )}
      </div>
    </div>
  );
}

interface LogoFormProps {
  users: User[];
  logo?: Logo;
  onSubmit: (data: InsertLogo) => void;
  isLoading: boolean;
}

function LogoForm({ users, logo, onSubmit, isLoading }: LogoFormProps) {
  const [formData, setFormData] = useState<InsertLogo>({
    name: logo?.name || "",
    description: logo?.description || "",
    imageUrl: logo?.imageUrl || "",
    category: logo?.category || "",
    tags: logo?.tags || [],
    userId: logo?.userId || null,
  });

  const [bulkMode, setBulkMode] = useState(false);
  const [bulkData, setBulkData] = useState("");

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (bulkMode) {
      handleBulkSubmit();
    } else {
      onSubmit({
        name: formData.name,
        imageUrl: formData.imageUrl,
        description: formData.description || undefined,
        category: formData.category || undefined,
        tags: formData.tags?.length ? formData.tags : undefined,
        userId: formData.userId,
      });
    }
  };

  const handleBulkSubmit = () => {
    const lines = bulkData.split('\n').filter(line => line.trim());
    lines.forEach(line => {
      const [name, imageUrl, description, category, tags] = line.split('\t').map(s => s?.trim());
      if (name && imageUrl) {
        const logoData: InsertLogo = {
          name,
          imageUrl,
          description: description || undefined,
          category: category || undefined,
          tags: tags ? tags.split(',').map(t => t.trim()).filter(Boolean) : undefined,
          userId: formData.userId,
        };
        onSubmit(logoData);
      }
    });
  };

  const handleTagsChange = (value: string) => {
    const tags = value.split(',').map(tag => tag.trim()).filter(Boolean);
    setFormData({ ...formData, tags });
  };

  return (
    <div className="space-y-4">
      {!logo && (
        <div className="flex gap-2 mb-4">
          <Button
            type="button"
            variant={!bulkMode ? "default" : "outline"}
            onClick={() => setBulkMode(false)}
            size="sm"
          >
            Single Upload
          </Button>
          <Button
            type="button"
            variant={bulkMode ? "default" : "outline"}
            onClick={() => setBulkMode(true)}
            size="sm"
          >
            Bulk Upload
          </Button>
        </div>
      )}

      <form onSubmit={handleSubmit} className="space-y-4">
        {bulkMode ? (
          <>
            <div>
              <label className="block text-sm font-medium mb-2">User (for all logos)</label>
              <Select value={formData.userId?.toString() || ""} onValueChange={(value) => setFormData({ ...formData, userId: value ? parseInt(value) : null })}>
                <SelectTrigger className="bg-slate-700 border-slate-600">
                  <SelectValue placeholder="Select user (optional)..." />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="">No User</SelectItem>
                  {users.map((user) => (
                    <SelectItem key={user.id} value={user.id.toString()}>
                      {user.username}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div>
              <label className="block text-sm font-medium mb-2">Bulk Data</label>
              <Textarea
                value={bulkData}
                onChange={(e) => setBulkData(e.target.value)}
                className="bg-slate-700 border-slate-600 min-h-[200px]"
                placeholder="Paste tab-separated data (copy from spreadsheet):
Name    Image URL       Description     Category        Tags

Example:
Client Logo 1   https://example.com/logo1.png   Modern design   Corporate       Professional, Clean
Client Logo 2   https://example.com/logo2.png           Creative        Bold, Artistic"
              />
              <p className="text-xs text-slate-400 mt-2">
                Only Name and Image URL are required. Other fields are optional.
              </p>
            </div>
          </>
        ) : (
          <>
            <div>
              <label className="block text-sm font-medium mb-2">User (optional)</label>
              <Select value={formData.userId?.toString() || ""} onValueChange={(value) => setFormData({ ...formData, userId: value ? parseInt(value) : null })}>
                <SelectTrigger className="bg-slate-700 border-slate-600">
                  <SelectValue placeholder="Select user (optional)..." />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="">No User</SelectItem>
                  {users.map((user) => (
                    <SelectItem key={user.id} value={user.id.toString()}>
                      {user.username}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div>
              <label className="block text-sm font-medium mb-2">Logo Name *</label>
              <Input
                value={formData.name}
                onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                className="bg-slate-700 border-slate-600"
                required
              />
            </div>

            <div>
              <label className="block text-sm font-medium mb-2">Image URL *</label>
              <Input
                value={formData.imageUrl}
                onChange={(e) => setFormData({ ...formData, imageUrl: e.target.value })}
                className="bg-slate-700 border-slate-600"
                placeholder="https://example.com/logo.png"
                required
              />
            </div>

            <div>
              <label className="block text-sm font-medium mb-2">Description (optional)</label>
              <Textarea
                value={formData.description}
                onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                className="bg-slate-700 border-slate-600"
                placeholder="Describe the logo design..."
              />
            </div>

            <div>
              <label className="block text-sm font-medium mb-2">Category (optional)</label>
              <Select value={formData.category} onValueChange={(value) => setFormData({ ...formData, category: value })}>
                <SelectTrigger className="bg-slate-700 border-slate-600">
                  <SelectValue placeholder="Select category..." />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="">No Category</SelectItem>
                  <SelectItem value="Corporate">Corporate</SelectItem>
                  <SelectItem value="Creative">Creative</SelectItem>
                  <SelectItem value="Tech">Tech</SelectItem>
                  <SelectItem value="Healthcare">Healthcare</SelectItem>
                  <SelectItem value="Education">Education</SelectItem>
                  <SelectItem value="Retail">Retail</SelectItem>
                  <SelectItem value="Other">Other</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div>
              <label className="block text-sm font-medium mb-2">Tags (optional, comma-separated)</label>
              <Input
                value={formData.tags?.join(', ') || ''}
                onChange={(e) => handleTagsChange(e.target.value)}
                className="bg-slate-700 border-slate-600"
                placeholder="Modern, Professional, Bold"
              />
            </div>
          </>
        )}

        <Button type="submit" disabled={isLoading} className="w-full bg-blue-600 hover:bg-blue-700">
          {isLoading ? "Saving..." : logo ? "Update Logo" : bulkMode ? "Add All Logos" : "Add Logo"}
        </Button>
      </form>
    </div>
  );
}
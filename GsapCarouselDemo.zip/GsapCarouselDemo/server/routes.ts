import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { insertFeedbackSchema, insertLogoSchema, insertUserSchema } from "@shared/schema";
import { z } from "zod";

export async function registerRoutes(app: Express): Promise<Server> {
  // Get logos from active collection
  app.get("/api/logos", async (req, res) => {
    try {
      const logos = await storage.getActiveCollectionLogos();
      res.json(logos);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch logos" });
    }
  });

  // Get single logo
  app.get("/api/logos/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ message: "Invalid logo ID" });
      }

      const logo = await storage.getLogo(id);
      if (!logo) {
        return res.status(404).json({ message: "Logo not found" });
      }

      res.json(logo);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch logo" });
    }
  });

  // Submit feedback
  app.post("/api/feedback", async (req, res) => {
    try {
      const validatedData = insertFeedbackSchema.parse(req.body);
      
      // No need to validate rating anymore since it's just thumbs up/down

      // Verify logo exists if logoId is provided
      if (validatedData.logoId) {
        const logo = await storage.getLogo(validatedData.logoId);
        if (!logo) {
          return res.status(404).json({ message: "Logo not found" });
        }
      }

      const feedback = await storage.createFeedback(validatedData);
      res.status(201).json(feedback);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ 
          message: "Invalid feedback data",
          errors: error.errors 
        });
      }
      res.status(500).json({ message: "Failed to submit feedback" });
    }
  });

  // Get feedback for a specific logo
  app.get("/api/logos/:id/feedback", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ message: "Invalid logo ID" });
      }

      const feedback = await storage.getFeedbackByLogo(id);
      res.json(feedback);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch feedback" });
    }
  });

  // Get all feedback
  app.get("/api/feedback", async (req, res) => {
    try {
      const feedback = await storage.getAllFeedback();
      res.json(feedback);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch feedback" });
    }
  });

  // ADMIN ROUTES
  
  // Collections
  app.get("/api/collections", async (req, res) => {
    try {
      const collections = await storage.getAllCollections();
      res.json(collections);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch collections" });
    }
  });

  app.post("/api/collections", async (req, res) => {
    try {
      const collection = await storage.createCollection(req.body);
      res.status(201).json(collection);
    } catch (error) {
      res.status(500).json({ message: "Failed to create collection" });
    }
  });

  app.patch("/api/collections/:id/activate", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      await storage.setActiveCollection(id);
      res.json({ message: "Collection activated" });
    } catch (error) {
      res.status(500).json({ message: "Failed to activate collection" });
    }
  });
  
  // Get all users
  app.get("/api/users", async (req, res) => {
    try {
      const users = await storage.getAllUsers();
      res.json(users);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch users" });
    }
  });

  // Create user
  app.post("/api/users", async (req, res) => {
    try {
      const validatedData = insertUserSchema.parse(req.body);
      const user = await storage.createUser(validatedData);
      res.status(201).json(user);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ 
          message: "Invalid user data",
          errors: error.errors 
        });
      }
      res.status(500).json({ message: "Failed to create user" });
    }
  });

  // Admin: Get all logos (including user associations)
  app.get("/api/admin/logos", async (req, res) => {
    try {
      const logos = await storage.getAllLogosWithUsers();
      res.json(logos);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch logos" });
    }
  });

  // Admin: Create logo
  app.post("/api/admin/logos", async (req, res) => {
    try {
      const validatedData = insertLogoSchema.parse(req.body);
      const logo = await storage.createLogo(validatedData);
      res.status(201).json(logo);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ 
          message: "Invalid logo data",
          errors: error.errors 
        });
      }
      res.status(500).json({ message: "Failed to create logo" });
    }
  });

  // Admin: Update logo
  app.patch("/api/admin/logos/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ message: "Invalid logo ID" });
      }

      const partialData = insertLogoSchema.partial().parse(req.body);
      const logo = await storage.updateLogo(id, partialData);
      
      if (!logo) {
        return res.status(404).json({ message: "Logo not found" });
      }

      res.json(logo);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ 
          message: "Invalid logo data",
          errors: error.errors 
        });
      }
      res.status(500).json({ message: "Failed to update logo" });
    }
  });

  // Admin: Delete logo
  app.delete("/api/admin/logos/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ message: "Invalid logo ID" });
      }

      const success = await storage.deleteLogo(id);
      
      if (!success) {
        return res.status(404).json({ message: "Logo not found" });
      }

      res.json({ message: "Logo deleted successfully" });
    } catch (error) {
      res.status(500).json({ message: "Failed to delete logo" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}

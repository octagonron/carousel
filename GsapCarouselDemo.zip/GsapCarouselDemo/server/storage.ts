import { users, logos, feedback, collections, type User, type InsertUser, type Logo, type InsertLogo, type Feedback, type InsertFeedback, type Collection, type InsertCollection } from "@shared/schema";
import { db } from "./db";
import { eq, isNull } from "drizzle-orm";

export interface IStorage {
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  getAllUsers(): Promise<User[]>;
  
  getAllCollections(): Promise<Collection[]>;
  createCollection(collection: InsertCollection): Promise<Collection>;
  setActiveCollection(id: number): Promise<void>;
  getActiveCollectionLogos(): Promise<Logo[]>;
  
  getAllLogos(): Promise<Logo[]>;
  getLogo(id: number): Promise<Logo | undefined>;
  createLogo(logo: InsertLogo): Promise<Logo>;
  getAllLogosWithUsers(): Promise<Logo[]>;
  updateLogo(id: number, data: Partial<InsertLogo>): Promise<Logo | undefined>;
  deleteLogo(id: number): Promise<boolean>;
  
  createFeedback(feedback: InsertFeedback): Promise<Feedback>;
  getFeedbackByLogo(logoId: number): Promise<Feedback[]>;
  getAllFeedback(): Promise<Feedback[]>;
}

export class DatabaseStorage implements IStorage {
  constructor() {
    // Initialize with sample logos on first run
    this.initializeLogos();
  }

  private async initializeLogos() {
    try {
      // Check if logos already exist
      const existingLogos = await db.select().from(logos);
      if (existingLogos.length > 0) {
        return; // Data already exists
      }

      const sampleLogos: InsertLogo[] = [
        {
          name: "Portfolio Logo 1",
          description: "Your unique logo design showcasing creative visual identity.",
          imageUrl: "/logos/1.svg",
          category: "Portfolio",
          tags: ["Original", "Design"]
        },
        {
          name: "Portfolio Logo 2", 
          description: "Your creative branding solution with distinctive elements.",
          imageUrl: "/logos/2.svg",
          category: "Portfolio",
          tags: ["Creative", "Branding"]
        },
        {
          name: "Portfolio Logo 3",
          description: "Your logo concept with balanced visual composition.",
          imageUrl: "/logos/3.svg",
          category: "Portfolio", 
          tags: ["Visual", "Identity"]
        },
        {
          name: "Portfolio Logo 4",
          description: "Your distinctive brand mark with artistic appeal.",
          imageUrl: "/logos/4.svg",
          category: "Portfolio",
          tags: ["Artistic", "Brand"]
        },
        {
          name: "Portfolio Logo 5",
          description: "Your logo design emphasizing clarity and impact.",
          imageUrl: "/logos/5.svg",
          category: "Portfolio",
          tags: ["Impact", "Clear"]
        },
        {
          name: "Portfolio Logo 6",
          description: "Your dynamic visual identity with strong concept.",
          imageUrl: "/logos/6.svg",
          category: "Portfolio",
          tags: ["Dynamic", "Concept"]
        },
        {
          name: "Portfolio Logo 7",
          description: "Your elegant brand symbol with modern execution.",
          imageUrl: "/logos/7.svg",
          category: "Portfolio",
          tags: ["Elegant", "Modern"]
        },
        {
          name: "Portfolio Logo 8",
          description: "Your bold logo design optimized for various media.",
          imageUrl: "/logos/8.svg",
          category: "Portfolio",
          tags: ["Bold", "Versatile"]
        },
        {
          name: "Portfolio Logo 9",
          description: "Your refined corporate identity design.",
          imageUrl: "/logos/9.svg",
          category: "Portfolio",
          tags: ["Corporate", "Refined"]
        },
        {
          name: "Portfolio Logo 10",
          description: "Your innovative brand concept with unique styling.",
          imageUrl: "/logos/10.svg",
          category: "Portfolio",
          tags: ["Innovative", "Unique"]
        }
      ];

      // Insert all logos
      await db.insert(logos).values(sampleLogos);
    } catch (error) {
      console.log('Error initializing logos:', error);
    }
  }

  async getUser(id: number): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user || undefined;
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.username, username));
    return user || undefined;
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const [user] = await db
      .insert(users)
      .values(insertUser)
      .returning();
    return user;
  }

  async getAllUsers(): Promise<User[]> {
    return await db.select().from(users);
  }

  async getAllCollections(): Promise<Collection[]> {
    return await db.select().from(collections);
  }

  async createCollection(insertCollection: InsertCollection): Promise<Collection> {
    const [collection] = await db
      .insert(collections)
      .values(insertCollection)
      .returning();
    return collection;
  }

  async setActiveCollection(id: number): Promise<void> {
    // Deactivate all collections first
    await db.update(collections).set({ isActive: false });
    // Activate the selected collection
    await db.update(collections).set({ isActive: true }).where(eq(collections.id, id));
  }

  async getActiveCollectionLogos(): Promise<Logo[]> {
    const [activeCollection] = await db.select().from(collections).where(eq(collections.isActive, true));
    if (!activeCollection) {
      return await db.select().from(logos).where(isNull(logos.collectionId));
    }
    return await db.select().from(logos).where(eq(logos.collectionId, activeCollection.id));
  }

  async getAllLogos(): Promise<Logo[]> {
    return await db.select().from(logos);
  }

  async getLogo(id: number): Promise<Logo | undefined> {
    const [logo] = await db.select().from(logos).where(eq(logos.id, id));
    return logo || undefined;
  }

  async createLogo(insertLogo: InsertLogo): Promise<Logo> {
    const [logo] = await db
      .insert(logos)
      .values(insertLogo)
      .returning();
    return logo;
  }

  async getAllLogosWithUsers(): Promise<Logo[]> {
    return await db.select().from(logos);
  }

  async updateLogo(id: number, data: Partial<InsertLogo>): Promise<Logo | undefined> {
    const [logo] = await db
      .update(logos)
      .set(data)
      .where(eq(logos.id, id))
      .returning();
    return logo || undefined;
  }

  async deleteLogo(id: number): Promise<boolean> {
    const result = await db.delete(logos).where(eq(logos.id, id));
    return (result.rowCount ?? 0) > 0;
  }

  async createFeedback(insertFeedback: InsertFeedback): Promise<Feedback> {
    const [feedbackItem] = await db
      .insert(feedback)
      .values(insertFeedback)
      .returning();
    return feedbackItem;
  }

  async getFeedbackByLogo(logoId: number): Promise<Feedback[]> {
    return await db.select().from(feedback).where(eq(feedback.logoId, logoId));
  }

  async getAllFeedback(): Promise<Feedback[]> {
    return await db.select().from(feedback);
  }
}

export const storage = new DatabaseStorage();
